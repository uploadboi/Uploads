//Die Main-Methode
import de.hamster.debugger.model.Territorium;import de.hamster.debugger.model.Territory;import de.hamster.model.HamsterException;import de.hamster.model.HamsterInitialisierungsException;import de.hamster.model.HamsterNichtInitialisiertException;import de.hamster.model.KachelLeerException;import de.hamster.model.MauerDaException;import de.hamster.model.MaulLeerException;import de.hamster.model.MouthEmptyException;import de.hamster.model.WallInFrontException;import de.hamster.model.TileEmptyException;public class Aufgabe1_Script extends de.hamster.debugger.model.IHamster implements de.hamster.model.HamsterProgram {public void main() {
    gehzugaengen1();
    gaengeleeren();
    gehzugaengen2();
    gaengeleeren();
    gaengeleeren_spezial();
    vor();
    vor();
    gaengeleeren_mitte();
    vor();
    gaengeleeren();
    vor();
    rechtsUm();
    vor();
    gaengeleeren();
    gehzugaengen3();
    gaengeleeren();
    gaengeleeren_spezial();
    gehzugaengen1();
    gaengeleeren();
    vor();
    vor();
    rechtsUm();
    
}

//Sammelt horizontale G�nge
void gaengeleeren() {

	linksUm();
	while(vornFrei()){
		vor();
	
	}
	nimm();
	linksUm();
	linksUm();
	verlassegaenge();
	linksUm();

}

//Sammelt vertikale G�nge
void gaengeleeren_spezial() {

	while(vornFrei()){
		vor();
	
	}
	nimm();
	linksUm();
	linksUm();
	verlassegaenge();
	linksUm();

}
//Sammelt den Gang in der Mitte
void gaengeleeren_mitte() {

	rechtsUm();
	while(vornFrei()){
		vor();
	}
	nimm();
	linksUm();
	linksUm();
	verlassegaenge();
	rechtsUm();
}

//L�uft zu G�ngen die zwei Felder entfernt sind
void gehzugaengen1(){
	vor();
	vor();
}

//L�uft zu G�ngen die drei Felder entfernt sind
void gehzugaengen2(){
	vor();
	vor();
	vor();
}

//L�uft zu G�ngen die vier Felder entfernt sind
void gehzugaengen3(){
	vor();
	vor();
	vor();
	vor();
}

//Verl�sst die Gaenge
void verlassegaenge(){
	vor();
	vor();
	vor();
}

//L�uft rechts
void rechtsUm(){
	linksUm();
	linksUm();
	linksUm();
}}