import de.hamster.debugger.model.Territorium;import de.hamster.debugger.model.Territory;import de.hamster.model.HamsterException;import de.hamster.model.HamsterInitialisierungsException;import de.hamster.model.HamsterNichtInitialisiertException;import de.hamster.model.KachelLeerException;import de.hamster.model.MauerDaException;import de.hamster.model.MaulLeerException;import de.hamster.model.MouthEmptyException;import de.hamster.model.WallInFrontException;import de.hamster.model.TileEmptyException;public class Bergsteigen extends de.hamster.debugger.model.IHamster implements de.hamster.model.HamsterProgram {boolean oben;

public void main() {
   	oben = false;
    action();
}

void rechtsUm(){
	linksUm();
	linksUm();
	linksUm();
}


void action(){
	while(!oben){
		stufeHoch();
		if(vornFrei()){
			oben= true;
		}
	}
	
	stufeRunter();
	
	while(oben){
		flaechenCheck();
		stufeRunter();
	}

}

void stufeHoch(){

	linksUm();
	vor();
	rechtsUm();
	vor();
}

void stufeRunter(){
	
	vor();
	rechtsUm();	
	vor();
	linksUm();
	
}


void flaechenCheck(){
	vor();
	rechtsUm();
	if(vornFrei()){
		rechtsUm();
		vor();
		linksUm();
		linksUm();
	}
	else{
		linksUm();
		while(vornFrei()){
			vor();
		
		
		}
	
	}


}
}